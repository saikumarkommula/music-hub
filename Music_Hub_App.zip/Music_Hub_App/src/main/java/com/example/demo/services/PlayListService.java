package com.example.demo.services;

public interface PlayListService {

}
